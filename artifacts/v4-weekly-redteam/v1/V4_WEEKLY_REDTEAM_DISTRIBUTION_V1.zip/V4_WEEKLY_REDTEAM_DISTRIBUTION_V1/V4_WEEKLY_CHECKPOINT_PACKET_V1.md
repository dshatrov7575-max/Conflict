# V4 — недельная контрольная точка и план на 7 дней

```text
PACKET_ID = V4_WEEKLY_REDTEAM_PACKET_V1
VERSION = 1.0
STATUS = FROZEN_OPERATIONAL_CHECKPOINT
FACT_CUTOFF_UTC = 2026-08-27T00:05:00Z
PURPOSE = независимая критика и коррекция ближайшего семидневного плана
SCIENTIFIC_FREEZE = no
PRODUCTION_STUDIO_C_AUTHORIZED = no
MERGE/REBASE/FORCE_PUSH = forbidden
```

## 1. Главный вопрос рецензирования

Какой семидневный план даст максимальный прирост демонстрируемости ConflictAnalysis Studio партнёрам, не создавая технический или научный долг и не ослабляя границы доказательности?

Рецензент должен проверить не только отдельные пункты, но и порядок зависимостей, реалистичность мощности исполнителей, stop conditions и риск ложного ощущения готовности.

## 2. Проверенные технические факты

### 2.1 Foundation Studio Contract Addendum

```text
PR = #66
STATE = OPEN / DRAFT / MERGEABLE / UNMERGED
ACCEPTED_HEAD = b8a543c09cc89b1b7378f21215f70afa586b248d
ACCEPTED_TREE = 8f9e0438e452693b9b9c312f7e5d5e7bd5ce499f
DELTA = 6 commits / 29 files / +10770 -163
MAIN_ACCEPTANCE = Issue #23 comment 5430266450
```

Приняты typed project-definition lifecycle, HUMAN/SERVICE attribution, capability checks, immutable evidence/provenance boundaries, Foundation 2.1 contract и PostgreSQL concurrency gates. PR не слит.

### 2.2 Foundation application gateways B

```text
PR = #67
STATE = OPEN / DRAFT / MERGEABLE / UNMERGED
ACCEPTED_HEAD = 5f73ebf2fd29a161a34ea047c7eead4fb0c582d4
ACCEPTED_TREE = ea5ff9ab510cb76f0c2b1bfda1c02c1278812aae
BASE_HEAD = b8a543c09cc89b1b7378f21215f70afa586b248d
BASE_TREE = 8f9e0438e452693b9b9c312f7e5d5e7bd5ce499f
DELTA = 6 fast-forward commits / exact 8 paths / +3678 -46
CI_RUN = 33024658200 / SUCCESS
CI_SYNTHETIC_MERGE = 315935ed2bcfb4a84b0689a3e3cb834f40a3f0ac
MERGE_PARENTS = [b8a543c09cc89b1b7378f21215f70afa586b248d, 5f73ebf2fd29a161a34ea047c7eead4fb0c582d4]
TREE_M_EQUALS_TREE_HEAD = yes
POSTGRESQL18 = 175 passed
SQLITE = 169 passed + 6 expected PostgreSQL-only skips
MAIN_ACCEPTANCE = Issue #24 comment 5432500079
PR_REVIEW = 5036019376
BLOCKERS_B = none
```

Закрыты lifecycle-complete read, successor publication, Foundation 2.1 preview/attempt/export, first-Project/first-DRAFT bootstrap, stable 409 conflicts и bounded HTTP admission. Session/Basic form и multipart rejection доказаны как zero-read; oversized/unknown/mismatched/preloaded bodies не создают partial identity или receipt.

### 2.3 Presentation-only Studio Showcase

```text
PR = #65
STATE = OPEN / DRAFT / MERGEABLE / UNMERGED
ACCEPTED_HEAD = d6ecbd85323b1da781f5fb2be6c57fcae3e87055
ACCEPTED_TREE = 4c55da6079b9908100ae53980020970357aa08fc
OWNER_ZIP_SHA256 = 33e3fb850a0d2091c4903125344470b9010b95975faa4000205269d160903ac0
MANIFEST_JSON_SHA256 = e4e870ea54b584a08fb00fde38fa22ffe5331321ce86c541183b5276183777b8
STATUS = runnable research prototype / not production / not release
RECORDED_CONSECUTIVE_WINDOWS_REHEARSAL_PASSES = 0
```

Showcase содержит loopback-only launcher, DEBUG=false, editors, 6×8 и 3×4, arbitrary cardinality, import/export round-trip, validation diagnostics, resource limits и evidence trace. Он не пишет в Foundation ORM и не имитирует публикацию.

## 3. Научные факты и ограничения

```text
THEORY = TASK THEORY-CC-DELIVERY-004 active; no CHECKPOINT/FINAL after Issue #4 comment 5411308628
METHODOLOGY = A1 exact-byte calibration freeze active; no FROZEN_A1 or BLOCKED_A1 after Issue #5 comment 5426095399
ASSESSMENT_METHOD = C3/C4 construct QA oracle preregistered; evidence delivery absent after Issue #6 comment 5425509612
CASE_KAZAKHSTAN = C3/C4 dedicated acquisition active; no checksum-bound delivery after Issue #12 comment 5425430465
SHOWCASE_REHEARSAL = receipt template exists; no PASS receipt after Issue #63 comment 5430925002
HUMAN_CODING = not started
POWER = vector components only; no scalar POW, universal Power score or validated Power claim
BENCHMARK = no accepted superiority or non-inferiority result
PREDICTION / RISK SCORE / RECOMMENDATION = outside accepted scope
SCIENTIFIC_CONTROLPOINT = not reached
```

Доказательная трассировка повышает reconstructability, но сама по себе не доказывает evidentiary adequacy или substantive correctness. Нельзя превращать UNKNOWN в ноль, traceability в качество вывода, presentation prototype в production readiness либо один кейс в универсальную валидность.

## 4. Нерешённые блокеры

1. Production Studio C не имеет отдельного принятого G0/code authorization после B.
2. Недельный red-team ещё не выдан независимым моделям.
3. Theory не вернула требуемый academic-foundation CHECKPOINT/FINAL.
4. Benchmark A1 exact-byte calibration packet не заморожен.
5. C3/C4 evidence candidates и construct QA не поставлены.
6. Нет двух последовательных Windows rehearsal PASS на exact OWNER ZIP.
7. Нет независимых HUMAN runs; научные freeze и superiority claims запрещены.

## 5. Ограничения мощности

```text
A1 = локальный Codex способен вести одну крупную техническую линию одновременно
A2 = научные workstreams могут идти параллельно, но AI не заменяет обязательных HUMAN-кодировщиков
A3 = Windows rehearsal требует владельца или иного оператора на целевой машине
A4 = независимые нейрорецензенты должны получить идентичные байты без доступа к ответам друг друга
A5 = merge, release и production/scientific claims не являются автоматическим результатом недельного плана
```

При провале предположения сокращать scope, а не ослаблять gate.

## 6. Кандидатный семидневный critical path

### День 0 — заморозка и выдача независимого review

- Заморозить этот packet, instruction и manifest по точным байтам.
- Выдать минимум трём независимым нейрорецензентам.
- Не авторизовывать Production Studio C до синтеза, кроме устранения доказанного аварийного дефекта.

**Stop:** несовпадение хешей, смешение версий, неподтверждённый факт в роли обязательства.

### День 1 — сбор независимой критики

- Получить отдельные обзоры без cross-review visibility.
- Проверить echoed hashes и полноту обязательного формата.
- Невалидные по binding ответы сохранить как INVALID_BINDING, но не смешивать с синтезом.

**Stop:** менее трёх валидных обзоров — явно понизить coverage, а не объявлять полноценный multi-model red team.

### День 2 — MAIN-синтез и решения по линиям

- Свести KEEP / CHANGE / DROP / DEFER по доказательности и зависимостям, не голосованием большинства.
- Выпустить исправленный план и отдельные authorization decisions.
- Решить, допускается ли bounded Production Studio C implementation, только design/G0 либо defer.

**Stop:** ослабление acceptance gates, изобретённая мощность, смешение prototype и production.

### Дни 2–4 — параллельные bounded-линии после авторизации

**TECHNICAL:** Production Studio C использует accepted Showcase UX поверх accepted Foundation gateways; запрещены second authority, formula, scalar Power, prediction и recommendation UI.

**BENCHMARK:** заморозить A1 exact-byte calibration packet; не запускать calibration до отдельной приёмки, не открывать confirmatory data, не задавать margins.

**POWER/EVIDENCE:** получить C3/C4 checksum-bound evidence candidates, затем construct-admissibility QA; не создавать answer key и не разрешать HUMAN coding преждевременно.

**THEORY:** вернуть V4_ACADEMIC_FOUNDATION_V1 CHECKPOINT/FINAL с lineage, novelty ledger, falsifiers и non-claims; не заявлять absolute novelty.

**DEMO:** выполнить два последовательных Windows rehearsal PASS на exact OWNER ZIP; любой fail/rebuild сбрасывает счётчик.

### День 5 — независимая приёмка фактически поставленного

- Проверить exact HEAD/TREE/hash/CI или exact packet checksums.
- Не принимать self-report без diff/evidence.
- Зафиксировать rejected/deferred вместе с причиной; не скрывать отрицательный результат.

### День 6 — partner-readiness dry run

- Продемонстрировать принятый executable path и static fallback.
- Вслух прочитать claim boundaries и known limitations.
- Проверить clean shutdown, import/export, resource limits и evidence trace.

**Stop:** checksum mismatch, orphan process, отсутствующие rehearsal receipts, overclaim.

### День 7 — недельное закрытие

- Записать accepted/rejected/deferred результаты, blockers и следующий critical path.
- Не выполнять автоматический merge, scientific freeze или Calculation Core activation.

## 7. Решения, которые должен проверить рецензент

1. Верен ли порядок: B acceptance → independent plan review → Production Studio C authorization?
2. Какие пункты плана не обеспечены реальной мощностью или входами?
3. Следует ли TECHNICAL lane начинать с отдельного G0, с кода либо отложить?
4. Какие scientific/demo линии являются настоящим critical path, а какие создают распыление?
5. Какие stop conditions отсутствуют или недостаточно жёстки?
6. Какие факты в packet сформулированы сильнее, чем подтверждают данные?
7. Какой лучший скорректированный 7-дневный план максимизирует демонстрируемый прогресс без technical/scientific debt?

## 8. Запреты для синтеза

- Не предлагать merge/rebase/force-push как способ «ускорения».
- Не заменять HUMAN coding результатами LLM.
- Не вводить scalar Power, формулы, risk scores, prediction или recommendations.
- Не объявлять production readiness, научную валидность или superiority.
- Не ослаблять exact-byte, CI, evidence, concurrency, rehearsal и claim gates.
- Не трактовать большинство рецензентов как доказательство.
