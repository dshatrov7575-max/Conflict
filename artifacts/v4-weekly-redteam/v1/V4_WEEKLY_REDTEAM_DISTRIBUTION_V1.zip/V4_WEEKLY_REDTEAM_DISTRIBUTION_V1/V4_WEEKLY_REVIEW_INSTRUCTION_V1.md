# Инструкция независимому рецензенту

```text
PACKET_ID = V4_WEEKLY_REDTEAM_PACKET_V1
INSTRUCTION_VERSION = 1.0
REVIEWER_ROSTER_ID = V4_WEEKLY_REDTEAM_ROSTER_V1
OUTSIDE_RESEARCH = forbidden
CROSS_REVIEW_VISIBILITY = no
LANGUAGE = русский
```

Работайте только с приложенным frozen packet. Не открывайте GitHub, интернет или ответы других рецензентов. Не исправляйте отсутствующие факты собственными догадками.

## Обязательный первый блок

До содержательного анализа повторите:

```text
PACKET_SHA256 = <полученное значение>
INSTRUCTION_SHA256 = <полученное значение>
MANIFEST_SHA256 = <полученное значение>
BINDING_STATUS = VALID | INVALID
```

При несовпадении хотя бы одного хеша верните только `INVALID_BINDING`.

## Требуемый анализ

1. Отделите подтверждённые факты от предположений и плановых решений.
2. Проведите red-team: найдите слабые места, пропущенные зависимости, overclaim, security/reliability gaps, scientific leakage и нереалистичную мощность.
3. Не ограничивайтесь критикой: предложите лучший исправленный гибридный план.
4. Не ослабляйте gates ради скорости.
5. Не оценивайте продукт по красоте текста; проверяйте причинную логику плана и исполнимость.

## Формат ответа

```text
REVIEW_STATUS = VALID_COMPLETE | VALID_INCOMPLETE | INVALID_BINDING
REVIEWER_SLOT = R1 | R2 | R3
MODEL_PROVIDER =
MODEL_NAME =
MODEL_VERSION_OR_DATE_AS_REPORTED =
PACKET_ID = V4_WEEKLY_REDTEAM_PACKET_V1
```

### A. FACT CHECK

Таблица:

```text
ITEM_ID | PACKET_CLAIM | SUPPORTED | OVERSTATED | UNSUPPORTED | REASON
```

### B. TOP RISKS

Не более 10 рисков:

```text
RISK_ID | SEVERITY=P0|P1|P2 | PROBABILITY=H|M|L | IMPACT | EVIDENCE | REQUIRED_CORRECTION
```

### C. PLAN DISPOSITION

Для каждого существенного пункта:

```text
ITEM | KEEP | CHANGE | DROP | DEFER | DEPENDENCY | STOP_CONDITION
```

### D. CRITICAL PATH

Дайте один скорректированный план День 0–7. Для каждого дня укажите:

```text
OBJECTIVE | OWNER/WORKSTREAM | INPUT | DELIVERABLE | ACCEPTANCE | STOP
```

### E. AUTHORIZATION RECOMMENDATIONS

Отдельно:

```text
PRODUCTION_STUDIO_C = AUTHORIZE_CODE | AUTHORIZE_G0_ONLY | DEFER
BENCHMARK_A1 = CONTINUE_FREEZE | BLOCKED
POWER_C3_C4 = CONTINUE_ACQUISITION | BLOCKED
THEORY = CONTINUE | DEFER
DEMO_REHEARSAL = RUN_NOW | DEFER
```

Каждое решение — с причиной и falsifier.

### F. THREE MOST IMPORTANT CHANGES

Ровно три изменения, которые дадут наибольший прирост при сохранении качества.

### G. UNCERTAINTY

Перечислите, что нельзя решить по packet. Не заполняйте пробелы общими знаниями.

Рекомендуемый объём: до 3000 слов. Никакого голосования, комплиментов или пересказа всего packet.
